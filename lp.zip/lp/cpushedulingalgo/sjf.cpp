#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

struct process{
	int id;
	int arrivalTime;
	int bustTime;
	int waitingTime;
	int turnAroundTime;
	int completionTime;
	
	process(int id, int arrival,int bust):id(id) , arrivalTime(arrival),bustTime(bust){};
};

bool compareBustTime(const process&p1 , const process&p2){
		return p1.bustTime<p2.bustTime;
	}

void sjf(vector<process>& processes){
	int n=processes.size();
	int totalWaitingTime =0;
	int totalTurnAroundTime=0;
	
	
	sort(processes.begin() ,processes.end() ,compareBustTime);
	processes[0].completionTime=processes[0].arrivalTime + processes[0].bustTime;
	
	for(int i=1;i<n;++i){
		processes[i].completionTime=max(processes[i-1].completionTime,processes[i].arrivalTime)+processes[i].bustTime;
	}
	
	for(int i=0;i<n;++i){
		processes[i].turnAroundTime=processes[i].completionTime-processes[i].arrivalTime;
		processes[i].waitingTime = processes[i].turnAroundTime-processes[i].bustTime;
		
		totalWaitingTime+=processes[i].waitingTime;
		totalTurnAroundTime += processes[i].turnAroundTime;
	}
	

	cout<<"############## SJF ###############"<<endl;
	cout<<" id  | Arrival Time  | Bust Time | Completion Time | Turn Around Time |Waiting Time \n";
	
	for(int i=0; i<n;i++){
		cout<<processes[i].id<<" "<<processes[i].arrivalTime<<" "<<processes[i].bustTime<<" "<<processes[i].completionTime<<"  "<<processes[i].turnAroundTime<<" "<<processes[i].waitingTime<<endl;
	
}
}

int main(){

	vector<process>processes;
	int n=0;
	
	cout<<"Enter the number of process";
	cin>>n;
	
	for(int i=0;i<n;i++){
		int arrival=0;
		int bust=0;
		cout<<"Enter the "<<i<<" Process arrival time";
		cin>>arrival;
		cout<<"Enter the "<<i<<" Process bust time";
		cin>>bust;
		processes.push_back(process(i+1,arrival,bust));
	}

	sjf(processes);
	return 0;
}

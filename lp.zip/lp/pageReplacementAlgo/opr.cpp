#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int  opr(vector<int>pages,int frameSize){
	vector<int>frame;
	int pagefault=0;
	
	for(int i=0;i<pages.size();i++){
		int page=pages[i];
		
		if(find(frame.begin(),frame.end(),page)!=frame.end()){
			continue;
		}
		if(frame.size()<frameSize){
			frame.push_back(page);
			pagefault++;
		}
		else{
			int farthest=-1;
			int pagetoreplace=-1;
			
			for(int j=0;j<frameSize;j++){
				int index=-1;
				for(int k=i+1;k<pages.size();k++){
				
					if(frame[j]==pages[k]){
						index=j;
						break;
					}
				}
				if(index==-1){
					pagetoreplace=j;
					break;
				}
				if(index>farthest){
					farthest=index;
					pagetoreplace=j;
					
				}
				
			}
			frame[pagetoreplace]=page;
			pagefault++;
		}
	}
	return pagefault;
}

int main(){
	vector<int> pages = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 0};
    int n = pages.size();
    int capacity = 3;  // Number of page frames in memory
    
    int result = opr(pages,capacity);
    
    cout << "Total Page Faults: " << result << endl;
	return 0;
}

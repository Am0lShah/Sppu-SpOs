#include <iostream>
#include <vector>
#include <unordered_map>
#include <climits>
#include <list>

using namespace std;

// Function to print the current state of frames
void printFrames(const vector<int>& frames) {
    for (int i = 0; i < frames.size(); i++) {
        if (frames[i] == -1) {
            cout << " - ";  // Represents an empty frame
        } else {
            cout << " " << frames[i] << " ";
        }
    }
    cout << endl;
}

int fifoPageReplacement(const vector<int>& pages, int frameSize) {
    int n = pages.size();
    vector<int> frames(frameSize, -1);
    int pageFaults = 0;
    int nextReplaceIndex = 0;

    for (int i = 0; i < n; i++) {
        bool pageFound = false;
        
        // Check if the page is already in the frames
        for (int j = 0; j < frameSize; j++) {
            if (frames[j] == pages[i]) {
                pageFound = true;
                break;
            }
        }

        if (!pageFound) {
            pageFaults++;
            cout << "Page fault! Inserting " << pages[i] << " into frames: ";
            frames[nextReplaceIndex] = pages[i];
            nextReplaceIndex = (nextReplaceIndex + 1) % frameSize;
            printFrames(frames);
        }
    }

    return pageFaults;
}


int main() {
    vector<int> pages = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 3};
    int frameSize = 3;
    cout << "\nFIFO Page Replacement:" << endl;
    int fifoFaults = fifoPageReplacement(pages, frameSize);
    cout << "Total page faults: " << fifoFaults << endl;
    
    return 0;
    
   }

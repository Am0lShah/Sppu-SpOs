#include<iostream> 
#include<vector>
using namespace std;

void printframes(vector<int> frames){
	for(int i=0;i<frames.size();i++){
		if(frames[i]==-1){
		cout<<" - ";
		}
		else{
		cout<<" "<<frames[i]<<" ";
		}
		
	}
}

int fifo(vector<int>pages,int frameSize){

	vector<int>frame(frameSize,-1);
	int pagefault=0;
	int nextIndex=0;
	
	for(int i=0;i<pages.size();i++){
		bool pagefound=false;
		
		for(int j=0;j<frameSize;j++){
			if(frame[j]==pages[i]){
				pagefound=true;
				cout<<" page found in frame "<<endl;
				break;
			}
		}
		
		if(!pagefound){
			pagefault++;
			cout<<" page inserting "<<pages[i]<<endl;
			frame[nextIndex]=pages[i];
			nextIndex=(nextIndex+1)%frameSize;
			printframes(frame);
		}
	}
return pagefault;
}

int main(){

	vector<int> pages{2,3,4,2,4,5,6,2,4};
	int pf=fifo(pages,4);
	return 0;
}

#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>

using namespace std;

class Semaphore {
private:
    mutex mtx;               // Mutex for synchronization
    condition_variable cv;   // Condition variable for blocking and waking threads
    int count;               // Number of available resources (initial count)

public:
    // Constructor to initialize the semaphore with a specific count
    Semaphore(int initial_count) : count(initial_count) {}

    // Wait (P operation) - Decrement the semaphore and block if count is 0
    void wait() {
        unique_lock<mutex> lock(mtx);  // Lock the mutex
        while (count == 0) {
            cv.wait(lock);  // Wait until the semaphore count is > 0
        }
        --count;  // Decrease the count (acquire the resource)
    }

    // Signal (V operation) - Increment the semaphore and notify one waiting thread
    void signal() {
        unique_lock<mutex> lock(mtx);  // Lock the mutex
        ++count;  // Increase the count (release the resource)
        cv.notify_one();  // Notify one waiting thread (if any)
    }

    // Get the current value of the semaphore
    int get_count() {
        unique_lock<mutex> lock(mtx);
        return count;
    }
};

// Simulating a process that uses the semaphore
void process(Semaphore& sem, int id) {
    cout << "Process " << id << " is waiting to enter...\n";
    sem.wait();  // Wait for the semaphore to be available

    cout << "Process " << id << " has entered the critical section.\n";
    this_thread::sleep_for(chrono::seconds(1)); // Simulate some work

    cout << "Process " << id << " is leaving the critical section.\n";
    sem.signal();  // Signal that the process has finished and released the semaphore
}

int main() {
    Semaphore sem(3);  // Create a semaphore with 3 resources

    // Launch several threads (simulating multiple processes)
    vector<thread> threads;
    for (int i = 0; i < 5; ++i) {
        threads.push_back(thread(process, ref(sem), i + 1));
    }

    // Join all threads
    for (auto& t : threads) {
        t.join();
    }

    return 0;
}


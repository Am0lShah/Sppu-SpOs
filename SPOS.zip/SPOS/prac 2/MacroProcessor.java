import java.util.*;
import java.io.*;

public class MacroProcessor {

    // Data Structures for Pass-I and Pass-II
    static List<String> MNT = new ArrayList<>();
    static List<String> MDT = new ArrayList<>();
    static List<List<String>> ALA = new ArrayList<>();
    static List<String> intermediateCode = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        String inputFile = "input.txt"; // Input file containing the source code
        String pass1OutputFile = "pass1_output.txt"; // Output file for Pass-I
        String pass2OutputFile = "pass2_output.txt"; // Output file for Pass-II

        // Step 1: Read input
        List<String> inputLines = readFile(inputFile);

        // Step 2: Pass-I processing (Macro Expansion)
        pass1(inputLines);

        // Step 3: Write Pass-I output (MNT, MDT, and intermediate code)
        writePass1Output(pass1OutputFile);

        // Step 4: Pass-II processing (Macro Expansion with Arguments)
        pass2();

        // Step 5: Write Pass-II output
        writePass2Output(pass2OutputFile);
    }

    // Read input file and return lines
    private static List<String> readFile(String filename) throws IOException {
        List<String> lines = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = br.readLine()) != null) {
            lines.add(line.trim());
        }
        br.close();
        return lines;
    }

    // Pass-I: Detect macros and create MNT, MDT, ALA and intermediate code
    private static void pass1(List<String> inputLines) {
        boolean inMacroDefinition = false;
        String currentMacroName = null;
        List<String> currentMacro = new ArrayList<>();
        List<String> currentArguments = new ArrayList<>();

        for (String line : inputLines) {
            if (line.startsWith("MACRO")) {
                inMacroDefinition = true;
                currentMacroName = inputLines.get(inputLines.indexOf(line) + 1).trim();
                MNT.add(currentMacroName);
                currentArguments.clear();
                currentMacro.clear();
            } else if (line.startsWith("MEND")) {
                MDT.addAll(currentMacro);
                ALA.add(currentArguments);
                inMacroDefinition = false;
            } else if (inMacroDefinition) {
                String[] parts = line.split(" ");
                if (parts[0].startsWith("&")) {
                    // Collecting arguments of macros
                    currentArguments.add(parts[0]);
                }
                currentMacro.add(line);
            } else {
                // Processing non-macro code (Intermediate code)
                intermediateCode.add(line);
            }
        }
    }

    // Write Pass-I output
    private static void writePass1Output(String outputFile) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

        // Write ALA
        writer.write("===== PASS 1 =====\nALA:\n");
        for (List<String> args : ALA) {
            writer.write(String.join(",", args));
            writer.write("\n");
        }

        // Write MNT
        writer.write("MNT:\n");
        for (String macroName : MNT) {
            writer.write(macroName + "\n");
        }

        // Write MDT
        writer.write("MDT:\n");
        for (String mdtLine : MDT) {
            writer.write(mdtLine + "\n");
        }

        // Write intermediate code
        writer.write("===== Pass 2 =====\n");
        for (String line : intermediateCode) {
            writer.write(line + "\n");
        }

        writer.close();
    }

    // Pass-II: Replace macro calls with actual macro definitions
    private static void pass2() {
        for (int i = 0; i < intermediateCode.size(); i++) {
            String line = intermediateCode.get(i);
            for (String macroName : MNT) {
                if (line.contains(macroName)) {
                    List<String> macroDefinition = getMacroDefinition(macroName);
                    // Replace the macro with its definition
                    intermediateCode.set(i, String.join("\n", macroDefinition));
                }
            }
        }
    }

    // Get Macro Definition from MDT
    private static List<String> getMacroDefinition(String macroName) {
        List<String> macroDefinition = new ArrayList<>();
        int index = MNT.indexOf(macroName);
        if (index != -1) {
            // Add lines from MDT starting at the index of the macro
            int startIdx = index;
            macroDefinition.add(MDT.get(startIdx));
        }
        return macroDefinition;
    }

    // Write Pass-II output
    private static void writePass2Output(String outputFile) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
        for (String line : intermediateCode) {
            writer.write(line + "\n");
        }
        writer.close();
    }
}

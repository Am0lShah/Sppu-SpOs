#include <iostream>
#include <vector>
#include <iomanip> // For table formatting

using namespace std;

class MemoryManagement {
protected:
    vector<int> memoryBlocks;  // Stores sizes of memory blocks
    vector<int> processSizes;  // Stores sizes of processes
    vector<int> allocatedBlock;  // Tracks allocated block for each process
    vector<int> blockSizeRem;  // Tracks remaining block size after allocation
    int numProcesses;

public:
    MemoryManagement() {
        // Input memory block sizes
        cout << "Enter sizes of the memory blocks (space-separated): ";
        int size;
        while (cin.peek() != '\n') {
            cin >> size;
            memoryBlocks.push_back(size);
        }
        cin.ignore();  // Clear the newline after input

        // Input number of processes
        cout << "Enter number of processes: ";
        cin >> numProcesses;

        // Input process sizes
        cout << "Enter the sizes of the processes (space-separated): ";
        for (int i = 0; i < numProcesses; i++) {
            cin >> size;
            processSizes.push_back(size);
        }

        // Initialize the allocation tracking
        allocatedBlock.resize(numProcesses, -1);  // All processes initially unallocated
        blockSizeRem = memoryBlocks;  // Copy memory block sizes
    }

    void printTable() {
        // Print table header
        cout << left << setw(10) << "Process" << setw(15) << "Process Size" << setw(15) << "Block Number" 
             << setw(15) << "Block Size" << setw(15) << "Unused Memory" << endl;

        for (int i = 0; i < numProcesses; i++) {
            if (allocatedBlock[i] != -1) {
                // Print details of allocated block
                cout << left << setw(10) << (i + 1) << setw(15) << processSizes[i] << setw(15) << (allocatedBlock[i] + 1)
                     << setw(15) << memoryBlocks[allocatedBlock[i]] << setw(15) << blockSizeRem[allocatedBlock[i]] << endl;
            } else {
                // Print N/A for unallocated process
                cout << left << setw(10) << (i + 1) << setw(15) << processSizes[i] << setw(15) << "N/A" 
                     << setw(15) << "-" << setw(15) << "-" << endl;
            }
        }
        cout << endl;
    }
};

class FirstFit : public MemoryManagement {
public:
    FirstFit() : MemoryManagement() {}

    void execute() {
        // Iterate over all processes to allocate memory using First Fit strategy
        for (int i = 0; i < numProcesses; i++) {
            for (int block = 0; block < memoryBlocks.size(); block++) {
                // Check if the block is large enough for the process
                if (blockSizeRem[block] >= processSizes[i]) {
                    // Allocate block to the process
                    allocatedBlock[i] = block;
                    // Update the remaining block size
                    blockSizeRem[block] -= processSizes[i];
                    break;  // Exit the loop as soon as the first fit is found
                }
            }
        }

        cout << "\nFIRST FIT - Memory Allocation:\n";
        printTable();
    }
};

int main() {
    FirstFit ff;
    ff.execute();
    return 0;
}



/*### First Fit Memory Allocation Algorithm

**First Fit** is a memory allocation algorithm in which the first block of memory that is large enough to accommodate a process is allocated to it. The algorithm iterates through the available memory blocks in the order they appear and allocates the first block that is large enough. If no block is large enough, the process remains unallocated.

### Explanation of the Code:

This program simulates the **First Fit** memory allocation strategy. It works as follows:

1. **Input**: 
   - The user provides the sizes of memory blocks and the sizes of processes.
   - The program reads these inputs, and the memory blocks are stored in a vector, and the processes are stored in another vector.
  
2. **Memory Allocation**: 
   - The algorithm allocates the first memory block that is large enough to hold each process.
   - If a process cannot be allocated to any of the available blocks, it remains unallocated (marked as "N/A").

3. **Output**:
   - The program displays a table with process details, showing the process size, the block allocated to it, the size of the allocated block, and the unused memory in the allocated block after the process is assigned.

### Sample Input:
```
Enter sizes of the memory blocks (space-separated): 100 500 200 300
Enter number of processes: 4
Enter the sizes of the processes (space-separated): 212 417 112 426
```

### Explanation of the Input:
- Memory blocks: [100, 500, 200, 300]
- Number of processes: 4
- Process sizes: [212, 417, 112, 426]

### Output:

```
FIRST FIT - Memory Allocation:
Process    Process Size  Block Number   Block Size    Unused Memory
1          212           2              500           288
2          417           3              300           0
3          112           4              200           88
4          426           N/A            -             -
```

### Detailed Breakdown:

1. **Process 1 (Size 212)**:
   - The algorithm starts with memory block 1 (size 100) and finds that it is not large enough.
   - It moves to memory block 2 (size 500), which is large enough, so it is allocated to this block.
   - The remaining size in block 2 is 500 - 212 = 288.

2. **Process 2 (Size 417)**:
   - The algorithm checks memory block 1 (size 100) and block 2 (size 288, after allocation to process 1). Neither is large enough.
   - It moves to memory block 3 (size 200), which is also too small.
   - Finally, it finds memory block 4 (size 300), which is large enough and allocates it to process 2.
   - The remaining size in block 4 is 300 - 417 = 0.

3. **Process 3 (Size 112)**:
   - The algorithm checks the available blocks and finds that block 4 (size 200) is large enough.
   - It allocates block 4 to process 3, and the remaining size in block 4 is 200 - 112 = 88.

4. **Process 4 (Size 426)**:
   - The algorithm checks all the memory blocks but finds that none are large enough to accommodate process 4.
   - Therefore, process 4 is not allocated to any block.

### Code Walkthrough:

- **`vector<int> memoryBlocks`**: Stores the sizes of the memory blocks.
- **`vector<int> processSizes`**: Stores the sizes of the processes to be allocated.
- **`vector<int> allocatedBlock`**: Tracks which block each process is allocated to (initialized to `-1` for unallocated).
- **`vector<int> blockSizeRem`**: Tracks the remaining size of each memory block after a process is allocated.

### Key Methods:
1. **`printTable()`**:
   - This method prints a table showing the allocation status of each process.
   - It prints details like the process ID, size, allocated block, block size, and unused memory.
   
2. **`execute()`**:
   - This method implements the First Fit memory allocation logic. It iterates over each process and allocates the first available block that is large enough.
   - If a block is found, it reduces the block's remaining size and marks the process as allocated.
   - If no block is found, the process is marked as unallocated.

### Conclusion:

The **First Fit** memory allocation algorithm is simple and works efficiently in scenarios where memory blocks are generally free and have enough space for processes. However, it may not always result in the most efficient usage of memory, as processes may be allocated to blocks that could accommodate
 future processes more efficiently. This algorithm is often used because of its simplicity and speed in determining where to place processes.*/
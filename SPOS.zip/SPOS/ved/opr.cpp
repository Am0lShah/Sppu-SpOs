#include <iostream>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;

// Helper function to check if a page is in future references
bool isInFuture(const vector<int>& referenceString, int start, int page) {
    for (int i = start; i < referenceString.size(); i++) {
        if (referenceString[i] == page) {
            return true;
        }
    }
    return false;
}

// Helper function to find the next occurrence of a page
int nextOccurrence(const vector<int>& referenceString, int start, int page) {
    for (int i = start; i < referenceString.size(); i++) {
        if (referenceString[i] == page) {
            return i;
        }
    }
    return -1; // Not found
}

// Helper function to find the index of the page that will be used the latest (or never)
int findMaxIndex(const vector<int>& occurance) {
    int maxIndex = 0;
    int maxValue = occurance[0];

    for (int i = 1; i < occurance.size(); i++) {
        if (occurance[i] > maxValue) {
            maxIndex = i;
            maxValue = occurance[i];
        }
    }
    return maxIndex;
}

int main() {
    // Input: Number of frames
    cout << "Enter the number of frames: ";
    int capacity;
    cin >> capacity;

    // Frame list and variables
    vector<int> frames;
    int fault = 0;
    string pf;

    // Input: Reference string
    cout << "Enter the reference string: ";
    cin.ignore(); // To consume newline
    string line;
    getline(cin, line);
    stringstream ss(line);
    vector<int> referenceString;
    int temp;
    while (ss >> temp) {
        referenceString.push_back(temp);
    }

    // Output table header
    cout << "\nString\t";
    for (int i = 0; i < capacity; i++) {
        cout << i << " ";
    }
    cout << "Fault\n";

    // Occurrence array to keep track of the next use of a page
    vector<int> occurance(capacity, -1); // Fill with -1 to indicate no future occurrence yet

    // Processing the reference string
    for (int i = 0; i < referenceString.size(); i++) {
        int currentPage = referenceString[i];

        // If page is not in frames (page fault)
        if (find(frames.begin(), frames.end(), currentPage) == frames.end()) {
            if (frames.size() < capacity) {
                // Add the page to frames if there's space
                frames.push_back(currentPage);
            } else {
                // Finding page to replace using LRU logic
                for (int j = 0; j < frames.size(); j++) {
                    int pageInFrame = frames[j];
                    if (!isInFuture(referenceString, i + 1, pageInFrame)) {
                        // If the page is not used again, replace it
                        frames[j] = currentPage;
                        break;
                    } else {
                        // Find next occurrence of each page
                        occurance[j] = nextOccurrence(referenceString, i + 1, pageInFrame);
                    }
                }
                // Replace the page with the one having the farthest next occurrence
                int indexToReplace = findMaxIndex(occurance);
                frames[indexToReplace] = currentPage;
            }
            fault++;
            pf = "Yes";
        } else {
            pf = "No";
        }

        // Output the current state of frames and whether it was a fault
        cout << "   " << currentPage << "\t\t";
        for (int x : frames) {
            cout << x << " ";
        }
        for (int x = frames.size(); x < capacity; x++) {
            cout << "  ";
        }
        cout << pf << endl;
    }

    // Output total requests, faults, and fault rate
    cout << "\nTotal requests: " << referenceString.size() << endl;
    cout << "Total Page Faults: " << fault << endl;
    cout << "Fault Rate: " << (static_cast<double>(fault) / referenceString.size()) * 100 << "%" << endl;

    return 0;
}





/*This code implements the **Optimal Page Replacement** algorithm, which is a page replacement strategy used in operating systems to manage the contents of the page table (or memory frames). The goal of this algorithm is to minimize page faults by replacing the page that will not be used for the longest period of time in the future.

### Overview of the Optimal Page Replacement Algorithm:

In the **Optimal Page Replacement** algorithm:
- When a page fault occurs (i.e., the page is not currently in any of the available frames), the algorithm selects the page to be replaced based on which one will not be used for the longest time in the future.
- If a page is not needed anymore (i.e., it will not appear again in the future), it is replaced immediately.

### Key Components of the Code:

1. **Frames (`frames`)**: Stores the current pages in memory (frames).
2. **Reference String (`referenceString`)**: A sequence of page numbers that the process references.
3. **Occurrence (`occurance`)**: Keeps track of the next occurrence index of each page in the frames.

### Helper Functions:

1. **`isInFuture`**: Checks if a page will appear in the future reference string.
   - If the page is found later in the reference string, it returns `true`. Otherwise, `false`.
   
2. **`nextOccurrence`**: Finds the next occurrence of a page in the reference string.
   - It returns the index of the next occurrence or `-1` if the page is not found later.

3. **`findMaxIndex`**: Finds the index of the page in the frame that will be used the farthest into the future (or never).
   - This helps in determining which page to replace, as the page with the farthest next usage should be replaced.

### Main Process:

1. **Input**:
   - The user is prompted to input the number of frames and the reference string (page sequence).
   
2. **Page Fault Handling**:
   - The program checks if the current page is in the frames:
     - If the page is not found (page fault), it tries to find a frame to replace:
       - It first checks if there’s space in the frames. If so, the page is added.
       - If the frames are full, the program uses the Optimal Page Replacement strategy to find the page with the farthest next usage and replaces it.
   - If the page is found in the frames (no page fault), it continues.

3. **Output**:
   - For each page in the reference string, the program prints the current page, the state of the frames, and whether the page caused a page fault ("Yes" or "No").
   - After processing all the pages, it prints the total number of requests, page faults, and the fault rate.

### Sample Input:

```
Enter the number of frames: 3
Enter the reference string: 7 0 1 2 0 3 0 4 2 3
```

### Sample Output:

```
String   0 1 2 Fault
   7       7               Yes
   0       7 0             No
   1       7 0 1           No
   2       2 0 1           Yes
   0       2 0 1           No
   3       3 0 1           Yes
   0       3 0 1           No
   4       3 0 4           Yes
   2       2 0 4           Yes
   3       2 3 4           No

Total requests: 10
Total Page Faults: 6
Fault Rate: 60%
```

### Explanation of the Output:

- **Page Faults**: The program detects when a page is not in the frames and replaces one of the existing pages with the new page.
- For example:
  - At step 4, the page `2` is not in the frames (`[7, 0, 1]`), so it is added, and this is counted as a page fault.
  - At step 5, the page `0` is found in the frames, so it's not a fault.
  - At step 8, the page `4` replaces the page `7` because `7` is not used again in the future reference string.

- **Fault Rate**: It is the ratio of page faults to the total number of page requests:
  - Fault rate = (Number of faults / Total requests) * 100 = (6 / 10) * 100 = 60%.

### Code Walkthrough:

1. **Input Parsing**: The reference string is read as a space-separated line, and it's converted into an integer vector (`referenceString`).
   
2. **Page Replacement Logic**:
   - For each page in the reference string, the program checks if it's in the frames.
   - If the page is not in the frames, a page fault occurs, and the program needs to find a page to replace.
   - The `isInFuture()` function checks if the page in the frames will be used again in the future. If not, it's replaced.
   - The `findMaxIndex()` function identifies which page to replace based on the page that is used farthest in the future.

3. **Output**:
   - The current page, the status of the frames, and whether a fault occurred are displayed.
   - After processing all pages, the total number of requests, page faults, and fault rate are printed.

### Conclusion:

The **Optimal Page Replacement** algorithm is known for being the most efficient page replacement strategy since it minimizes the number of page faults. However, it is not practical for real-world use because it requires knowing the entire future reference string, which is not feasible in practice. The code implements this algorithm 
efficiently for educational purposes, showing how the page replacement works with a clear step-by-step breakdown.*/
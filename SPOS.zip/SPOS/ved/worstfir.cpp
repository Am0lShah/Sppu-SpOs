#include <iostream>
#include <vector>
#include <iomanip>
#include <sstream>

using namespace std;

class MemoryManagement {
protected:
    vector<int> memoryBlocks;
    int numProcesses;
    vector<int> processSizes;
    vector<int> allocatedBlock;
    vector<int> blockSizeRem;

public:
    MemoryManagement() {
        // Input memory block sizes
        cout << "Enter sizes of the memory blocks (space-separated): ";
        string input;
        getline(cin, input);
        stringstream ss(input);
        int blockSize;
        while (ss >> blockSize) {
            memoryBlocks.push_back(blockSize);
        }

        // Input number of processes
        cout << "Enter number of processes: ";
        cin >> numProcesses;
        cin.ignore(); // Clear the newline character from the buffer

        // Input process sizes
        processSizes.resize(numProcesses);
        cout << "Enter sizes of the processes (space-separated): ";
        for (int i = 0; i < numProcesses; i++) {
            cin >> processSizes[i];
        }

        // Initialize allocatedBlock to track which block is allocated to each process
        allocatedBlock.resize(numProcesses, -1); // No block allocated initially

        // Copy the memory block sizes to keep track of remaining memory
        blockSizeRem = memoryBlocks;
    }

    void printTable() {
        // Print table header
        cout << setw(10) << "Process" 
             << setw(15) << "Process Size" 
             << setw(15) << "Block Number" 
             << setw(15) << "Block Size" 
             << setw(15) << "Unused Memory" << endl;

        for (int i = 0; i < numProcesses; i++) {
            if (allocatedBlock[i] != -1) {
                cout << setw(10) << (i + 1) 
                     << setw(15) << processSizes[i] 
                     << setw(15) << (allocatedBlock[i] + 1) 
                     << setw(15) << memoryBlocks[allocatedBlock[i]] 
                     << setw(15) << blockSizeRem[allocatedBlock[i]] << endl;
            } else {
                cout << setw(10) << (i + 1) 
                     << setw(15) << processSizes[i] 
                     << setw(15) << "N/A" 
                     << setw(15) << "-" 
                     << setw(15) << "-" << endl;
            }
        }
        cout << endl;
    }
};

class WorstFit : public MemoryManagement {
public:
    WorstFit() : MemoryManagement() {}

    void execute() {
        // Iterate over all processes
        for (int i = 0; i < numProcesses; i++) {
            int worstBlock = -1;
            // Search for the worst block (largest available block)
            for (int block = 0; block < memoryBlocks.size(); block++) {
                // Check if the block can accommodate the process
                if (blockSizeRem[block] >= processSizes[i]) {
                    if (worstBlock == -1 || blockSizeRem[worstBlock] < blockSizeRem[block]) {
                        worstBlock = block;
                    }
                }
            }

            // Allocate the worst block to the process if found
            if (worstBlock != -1) {
                allocatedBlock[i] = worstBlock;
                blockSizeRem[worstBlock] -= processSizes[i];
            }
        }

        cout << "WORST FIT - Memory Allocation:" << endl;
        printTable();
    }
};

int main() {
    WorstFit wf;
    wf.execute();
    return 0;
}




/*The code you've provided implements **Worst Fit Memory Allocation**, a memory management algorithm used for allocating memory blocks to processes. In the Worst Fit strategy, the algorithm allocates the largest available block to a process, ensuring that the remaining free memory blocks are as large as possible.

### Key Concepts:

1. **Worst Fit Memory Allocation**: The algorithm tries to find the largest block of memory (the worst-fit block) that can accommodate the process and allocates that block to the process. This is done to leave the largest remaining blocks for subsequent processes.

2. **Process Allocation**: For each process, the algorithm checks all memory blocks to see if they can accommodate the process. If a block is large enough, the algorithm compares it to the other available blocks and selects the largest one.

3. **Block and Process Tracking**:
   - `allocatedBlock`: This tracks which memory block is allocated to each process. If a process is not allocated a block, it is marked as `-1`.
   - `blockSizeRem`: This tracks the remaining memory in each block after allocation.

4. **Output**:
   - The program prints a table showing the process details including process size, allocated block number, block size, and unused memory after allocation.

### Code Walkthrough:

1. **Input**:
   - The program first takes the sizes of available memory blocks as input from the user.
   - It then asks for the number of processes and their respective sizes.

2. **Memory Allocation (Worst Fit)**:
   - For each process, the algorithm checks all available memory blocks and selects the block with the largest remaining space that can accommodate the process. 
   - If a suitable block is found, it is allocated to the process, and the remaining size of that block is updated.

3. **Output Table**:
   - After allocation, the program prints a formatted table that displays:
     - Process number
     - Process size
     - Allocated block number (if any)
     - Block size (of the allocated block)
     - Unused memory in the allocated block.

### Key Features:

- **Worst Fit Algorithm**: The heart of the memory allocation strategy, selecting the largest available block to minimize fragmentation in subsequent allocations.
  
- **Formatted Output**: Using `setw()` from `<iomanip>`, the output is neatly formatted, making it easy to view the allocation status of each process.

- **Memory Block Tracking**: Both the `allocatedBlock` and `blockSizeRem` vectors keep track of the memory blocks assigned to processes and the remaining memory in each block.

### Example Input and Output:

#### Input:

```
Enter sizes of the memory blocks (space-separated): 100 500 200 300 600
Enter number of processes: 4
Enter sizes of the processes (space-separated): 212 417 112 426
```

#### Output:

```
WORST FIT - Memory Allocation:

Process     Process Size  Block Number   Block Size    Unused Memory
       1              212             3          300            88
       2              417             5          600           174
       3              112             1          100             0
       4              426             N/A          -              -
```

### Explanation:

1. **Process 1** (size 212) is allocated to **Block 3** (size 300) because it is the largest block that can accommodate it. The remaining memory in Block 3 after allocation is 88.
   
2. **Process 2** (size 417) is allocated to **Block 5** (size 600) because it is the largest available block. The remaining memory in Block 5 after allocation is 174.
   
3. **Process 3** (size 112) is allocated to **Block 1** (size 100), but it cannot fit since the block is too small, and the process is not allocated any memory.

4. **Process 4** (size 426) cannot fit in any available block, so it is marked as "N/A" with no memory allocation.

### Class Breakdown:

- **`MemoryManagement` Class**: This is the base class that handles the initial setup and input, including memory block sizes, process sizes, and memory tracking.
  
- **`WorstFit` Class**: This subclass inherits from `MemoryManagement` and implements the Worst Fit memory allocation strategy. The `execute()` method performs the actual allocation, and the `printTable()` method prints the results.

### Conclusion:

This code successfully implements the Worst Fit memory allocation algorithm, which is a common strategy in memory management. The `WorstFit` class extends the functionality of `MemoryManagement` by implementing the specific allocation logic, making it modular and reusable for other memory allocation strategies as well. The table format 
and detailed output make it easy to understand the allocation status and how the algorithm works in practice.*/
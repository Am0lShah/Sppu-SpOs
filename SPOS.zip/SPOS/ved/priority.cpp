#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;

struct Process {
    int id;
    int burst_time;
    int priority;
    int waiting_time;
    int turn_around_time;
    int completion_time;
};

// Function to perform priority scheduling
void priority_scheduling(vector<Process>& processes, int n) {
    // Sorting processes based on priority (higher priority = lower number)
    sort(processes.begin(), processes.end(), [](const Process& a, const Process& b) {
        return a.priority < b.priority;
    });

    // First process will have zero waiting time
    processes[0].waiting_time = 0;
    processes[0].completion_time = processes[0].burst_time;

    // Calculating waiting time and completion time for each process
    for (int i = 1; i < n; i++) {
        processes[i].waiting_time = processes[i - 1].completion_time;
        processes[i].completion_time = processes[i].waiting_time + processes[i].burst_time;
    }

    // Calculating turn around time
    for (int i = 0; i < n; i++) {
        processes[i].turn_around_time = processes[i].burst_time + processes[i].waiting_time;
    }

    // Calculate total waiting time and turn around time
    int total_waiting_time = 0, total_turn_around_time = 0;
    for (int i = 0; i < n; i++) {
        total_waiting_time += processes[i].waiting_time;
        total_turn_around_time += processes[i].turn_around_time;
    }

    // Print process information
    cout << "\nProcess  Burst Time  Priority  Waiting Time  Turn Around Time  Completion Time\n";
    for (const auto& process : processes) {
        cout << setw(7) << process.id << setw(11) << process.burst_time << setw(9)
             << process.priority << setw(14) << process.waiting_time << setw(17)
             << process.turn_around_time << setw(17) << process.completion_time << endl;
    }

    // Print average waiting time and turn around time
    cout << fixed << setprecision(2);
    cout << "\nAverage Waiting Time: " << (double)total_waiting_time / n << endl;
    cout << "Average Turn Around Time: " << (double)total_turn_around_time / n << endl;
}

int main() {
    cout << "Priority Scheduling (Non-Preemptive):" << endl;

    // Input number of processes
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<Process> processes(n);

    // Input process IDs
    cout << "Enter process IDs: ";
    for (int i = 0; i < n; i++) {
        cin >> processes[i].id;
    }

    // Input burst times
    cout << "Enter burst times: ";
    for (int i = 0; i < n; i++) {
        cin >> processes[i].burst_time;
    }

    // Input priorities
    cout << "Enter priorities: ";
    for (int i = 0; i < n; i++) {
        cin >> processes[i].priority;
    }

    // Call priority scheduling function
    priority_scheduling(processes, n);

    return 0;
}






/*The code you provided implements the **Priority Scheduling** algorithm for CPU scheduling, specifically a **non-preemptive** version. In this scheduling algorithm, each process is assigned a priority. The process with the highest priority (represented by the smallest priority value) is executed first. Once a process starts executing, it runs to completion without being preempted by any other process.

### Key Concepts of Priority Scheduling:

1. **Priority**: Each process is assigned a priority, where a lower value represents a higher priority.
2. **Burst Time**: The time required by each process for execution.
3. **Waiting Time**: The total time a process spends waiting in the ready queue before execution begins.
4. **Turnaround Time**: The total time a process spends from arrival to completion (Waiting time + Burst time).
5. **Completion Time**: The time at which a process finishes execution.

### Algorithm Explanation:

- **Step 1: Sorting**: The processes are first sorted based on their priority. The process with the highest priority (smallest priority number) is scheduled first.
- **Step 2: Waiting Time**: After sorting, the first process has zero waiting time, and for each subsequent process, the waiting time is calculated as the completion time of the previous process.
- **Step 3: Completion Time**: The completion time for each process is calculated based on its burst time and the waiting time.
- **Step 4: Turnaround Time**: The turnaround time is calculated as the sum of burst time and waiting time for each process.
- **Step 5: Output**: The program displays the details for each process, including Burst Time, Priority, Waiting Time, Turnaround Time, and Completion Time. It also calculates and displays the average Waiting Time and Turnaround Time.

### Code Walkthrough:

1. **Input**:
   - The user is asked to input the number of processes, burst times, and priorities for each process.
   - The input consists of three parts:
     - **Process IDs**: Identifiers for the processes.
     - **Burst Times**: The time each process takes to execute.
     - **Priorities**: The priority assigned to each process.

2. **Sorting**:
   - The processes are sorted based on their priority in ascending order (lower priority value means higher priority).

3. **Calculating Waiting Time and Turnaround Time**:
   - The waiting time for the first process is `0` (since it starts immediately).
   - For each subsequent process, the waiting time is the completion time of the previous process.
   - The turnaround time is calculated as the sum of burst time and waiting time for each process.

4. **Calculating Average Waiting Time and Turnaround Time**:
   - After all processes have been scheduled, the program calculates the average waiting time and the average turnaround time by summing the respective values and dividing by the number of processes.

5. **Output**:
   - The details of each process, including its burst time, priority, waiting time, turnaround time, and completion time, are printed in a neatly formatted table.
   - The average waiting time and average turnaround time are also printed with two decimal places of precision.

### Sample Input and Output:

**Input**:
```
Priority Scheduling (Non-Preemptive):
Enter number of processes: 4
Enter process IDs: 1 2 3 4
Enter burst times: 5 3 8 6
Enter priorities: 3 1 4 2
```

**Output**:
```
Process  Burst Time  Priority  Waiting Time  Turn Around Time  Completion Time
      2          3          1             0                3                3
      4          6          2             3                9               12
      1          5          3             9               14               17
      3          8          4            14               22               25

Average Waiting Time: 6.50
Average Turn Around Time: 12.00
```

### Explanation of Output:

- The processes are sorted based on their priority, so the process with the smallest priority value (Process 2 with priority 1) is executed first.
- For each process, the following details are printed:
  - **Process ID**: The ID of the process.
  - **Burst Time**: The time required to complete the process.
  - **Priority**: The priority of the process.
  - **Waiting Time**: The time the process waits before it starts executing.
  - **Turnaround Time**: The total time the process takes from arrival to completion.
  - **Completion Time**: The time at which the process finishes execution.

- The average waiting time is calculated as `(0 + 3 + 9 + 14) / 4 = 6.5`.
- The average turnaround time is calculated as `(3 + 9 + 14 + 22) / 4 = 12.0`.

### Code Adjustments and Comments:

- **`setw()`**: Used to format the output, aligning the columns properly for readability.
- **`fixed` and `setprecision(2)`**: These are used to format the floating-point output to 2 decimal places when displaying average waiting and turnaround times.

### Conclusion:

This code correctly implements the non-preemptive priority scheduling algorithm, which is a simple yet effective way to schedule processes based on priority. It handles multiple processes and computes important scheduling metrics like waiting time, turnaround time, and completion time. The output is neatly
 formatted, providing clear insight into the scheduling process for each task.*/
#include <iostream>
#include <vector>
#include <numeric> // For accumulate to calculate sum

using namespace std;

class FCFS {
private:
    int numProcesses;
    vector<int> processes;
    vector<int> arrivalTimes;
    vector<int> burstTimes;
    vector<int> waitingTimes;
    vector<int> turnAroundTimes;
    vector<int> completionTimes;

public:
    FCFS() {
        cout << "Enter number of processes: ";
        cin >> numProcesses;

        processes.resize(numProcesses);
        arrivalTimes.resize(numProcesses);
        burstTimes.resize(numProcesses);
        waitingTimes.resize(numProcesses, 0);
        turnAroundTimes.resize(numProcesses, 0);
        completionTimes.resize(numProcesses, 0);

        cout << "Enter processes (space-separated): ";
        for (int i = 0; i < numProcesses; i++) {
            cin >> processes[i];
        }

        cout << "Enter arrival times (space-separated): ";
        for (int i = 0; i < numProcesses; i++) {
            cin >> arrivalTimes[i];
        }

        cout << "Enter burst times (space-separated): ";
        for (int i = 0; i < numProcesses; i++) {
            cin >> burstTimes[i];
        }
    }

    void calcWaitTime() {
        for (int i = 1; i < numProcesses; i++) { // Start from 1 since process 0 has no wait time
            waitingTimes[i] = completionTimes[i - 1] - arrivalTimes[i];
            if (waitingTimes[i] < 0) { // If the process arrives later than previous completion
                waitingTimes[i] = 0;
            }
        }
    }

    void calcTurnAroundTime() {
        for (int i = 0; i < numProcesses; i++) {
            turnAroundTimes[i] = burstTimes[i] + waitingTimes[i];
        }
    }

    void calcCompletionTime() {
        completionTimes[0] = arrivalTimes[0] + burstTimes[0]; // First process
        for (int i = 1; i < numProcesses; i++) {
            completionTimes[i] = completionTimes[i - 1] + burstTimes[i];
        }
    }

    void calcAvgWaitingTime() {
        double avgWaitingTime = accumulate(waitingTimes.begin(), waitingTimes.end(), 0.0) / numProcesses;
        cout << "Average Waiting Time: " << avgWaitingTime << endl;
    }

    void calcAvgTurnAroundTime() {
        double avgTurnAroundTime = accumulate(turnAroundTimes.begin(), turnAroundTimes.end(), 0.0) / numProcesses;
        cout << "Average Turn Around Time: " << avgTurnAroundTime << endl;
    }

    void printTable() {
        cout << "\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurn Around Time\tCompletion Time\n";
        for (int i = 0; i < numProcesses; i++) {
            cout << processes[i] << "\t\t" << arrivalTimes[i] << "\t\t" << burstTimes[i]
                 << "\t\t" << waitingTimes[i] << "\t\t" << turnAroundTimes[i]
                 << "\t\t" << completionTimes[i] << endl;
        }
    }

    void calculateAll() {
        calcCompletionTime();
        calcWaitTime();
        calcTurnAroundTime();
        printTable();
        calcAvgWaitingTime();
        calcAvgTurnAroundTime();
    }
};

int main() {
    cout << "\nFirst Come First Serve Scheduling:\n";
    FCFS obj;
    obj.calculateAll();
    return 0;
}





/*### First-Come-First-Serve (FCFS) Scheduling

**FCFS** is one of the simplest scheduling algorithms in operating systems. In this algorithm, the process that arrives 
first gets executed first, meaning that the processes are scheduled in the order of their arrival times.

### Key Characteristics of FCFS:
1. **Non-preemptive**: Once a process starts its execution, it runs to completion.
2. **First Come First Served**: The process that arrives first is executed first.
3. **Simple to Implement**: FCFS is easy to implement as it doesn’t require any complex calculations.
4. **Drawback**: It may lead to the **convoy effect**, where short processes may have to wait for long processes to finish, increasing the overall waiting time.

### Terminology:
- **Arrival Time**: The time at which a process arrives in the ready queue.
- **Burst Time**: The time required for the process to complete its execution.
- **Waiting Time**: The total time a process spends in the ready queue before it starts execution. Calculated as:
  \[
  \text{Waiting Time} = \text{Completion Time} - \text{Arrival Time} - \text{Burst Time}
  \]
- **Turnaround Time**: The total time taken from the arrival of a process until it completes its execution. Calculated as:
  \[
  \text{Turnaround Time} = \text{Completion Time} - \text{Arrival Time}
  \]
- **Completion Time**: The time when a process completes its execution.

### FCFS Scheduling Procedure:
1. The processes are executed in the order they arrive.
2. For the first process, the completion time is its arrival time plus its burst time.
3. For the subsequent processes, the completion time is calculated by adding the burst time of the current process to the completion time of the previous process.
4. The waiting time for each process is the time between its arrival and the time it starts execution (i.e., the difference between its arrival time and the completion time of the process before it).
5. Turnaround time is the total time from arrival to completion.

### Sample Input/Output for the Given Code:

#### Sample Input:

```
Enter number of processes: 4
Enter processes (space-separated): 1 2 3 4
Enter arrival times (space-separated): 0 2 4 6
Enter burst times (space-separated): 5 3 8 6
```

#### Explanation of the Sample:

- Process 1 arrives at time 0 and has a burst time of 5.
- Process 2 arrives at time 2 and has a burst time of 3.
- Process 3 arrives at time 4 and has a burst time of 8.
- Process 4 arrives at time 6 and has a burst time of 6.

#### FCFS Calculation Steps:

1. **Completion Time Calculation**:
   - Process 1 completes at time: `0 + 5 = 5`
   - Process 2 completes at time: `5 + 3 = 8`
   - Process 3 completes at time: `8 + 8 = 16`
   - Process 4 completes at time: `16 + 6 = 22`

2. **Waiting Time Calculation**:
   - Waiting time for Process 1 = `0 - 0 = 0` (Since it starts execution immediately)
   - Waiting time for Process 2 = `5 - 2 = 3`
   - Waiting time for Process 3 = `8 - 4 = 4`
   - Waiting time for Process 4 = `16 - 6 = 10`

3. **Turnaround Time Calculation**:
   - Turnaround time for Process 1 = `5 - 0 = 5`
   - Turnaround time for Process 2 = `8 - 2 = 6`
   - Turnaround time for Process 3 = `16 - 4 = 12`
   - Turnaround time for Process 4 = `22 - 6 = 16`

4. **Average Waiting Time**:
   - Average Waiting Time = (0 + 3 + 4 + 10) / 4 = 17 / 4 = 4.25

5. **Average Turnaround Time**:
   - Average Turnaround Time = (5 + 6 + 12 + 16) / 4 = 39 / 4 = 9.75

#### Sample Output:

```
First Come First Serve Scheduling:

Process    Arrival Time    Burst Time    Waiting Time    Turn Around Time    Completion Time
1          0              5             0               5                   5
2          2              3             3               6                   8
3          4              8             4               12                  16
4          6              6             10              16                  22

Average Waiting Time: 4.25
Average Turn Around Time: 9.75
```

### Code Explanation:
- **`FCFS` Class Constructor**: Initializes the processes, arrival times, and burst times.
- **`calcCompletionTime`**: Computes the completion times for all processes.
- **`calcWaitTime`**: Computes the waiting times for all processes based on the completion time and arrival time.
- **`calcTurnAroundTime`**: Computes the turnaround times by adding the burst time to the waiting time for each process.
- **`calcAvgWaitingTime` and `calcAvgTurnAroundTime`**: Calculate the average waiting and turnaround times using `accumulate`.
- **`printTable`**: Displays the process scheduling results in a tabular format.

This algorithm is straightforward but can suffer from inefficiencies when processes have very different burst times. For instance, longer processes can cause a significant delay for shorter processes, leading to high waiting and turnaround times.*/
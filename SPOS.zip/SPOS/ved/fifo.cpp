#include <iostream>
#include <vector>
#include <algorithm> // Include for std::find
#include <iomanip>   // For setting precision of float

using namespace std;

int main() {
    int capacity, fault = 0, top = 0;
    string pf = "No";

    // Input the number of frames
    cout << "Enter the number of frames: ";
    cin >> capacity;

    // Frame array to store the pages and reference string
    vector<int> f;
    vector<int> s;
    int num;

    // Input the reference string
    cout << "Enter the reference string (space-separated): ";
    while (cin >> num) {
        s.push_back(num);
        if (cin.peek() == '\n') break;  // Stop reading when newline is encountered
    }

    // Output column headers
    cout << "\nString | Frame →\t";
    for (int i = 0; i < capacity; i++) {
        cout << i << " ";
    }
    cout << "Fault\n   ↓\n";

    // FIFO Page Replacement Algorithm
    for (int i = 0; i < s.size(); i++) {
        if (find(f.begin(), f.end(), s[i]) == f.end()) {  // Page fault occurs
            if (f.size() < capacity) {
                f.push_back(s[i]);  // Add page if there is space
            } else {
                f[top] = s[i];  // Replace the page in FIFO order
                top = (top + 1) % capacity;
            }
            fault++;
            pf = "Yes";
        } else {
            pf = "No";  // No page fault
        }

        // Print current reference and frame state
        cout << "   " << s[i] << "\t\t";
        for (int j = 0; j < f.size(); j++) {
            cout << f[j] << " ";
        }
        for (int j = 0; j < capacity - f.size(); j++) {
            cout << "  ";
        }
        cout << pf << endl;
    }

    // Calculate and print statistics
    cout << "\nTotal requests: " << s.size() << endl;
    cout << "Total Page Faults: " << fault << endl;
    cout << "Fault Rate: " << fixed << setprecision(2) << (float(fault) / s.size()) * 100 << "%" << endl;

    return 0;
}


/*### First-In-First-Out (FIFO) Page Replacement Algorithm

**FIFO (First-In-First-Out)** is a page replacement algorithm that manages the pages in memory by selecting the oldest page (the first page that was loaded into memory) for replacement when a page fault occurs. The idea is simple: when a page is needed but not currently in memory, it is loaded into memory. If the memory is full, the page that has been in memory the longest is replaced.

### Steps for FIFO Page Replacement:
1. Maintain a queue of pages in memory. If there is space in memory, the new page is added to the queue.
2. If memory is full, the page at the front of the queue (oldest page) is replaced by the new page.
3. A page fault occurs when a page is not found in memory.
4. For each page access, update the page queue and the page fault counter.

### Example Walkthrough:

#### Sample Input:
```
Enter the number of frames: 3
Enter the reference string (space-separated): 7 0 1 2 0 3 0 4 2 3 0 3
```

#### Explanation of the Input:
- Number of frames (capacity) = 3.
- Reference string: [7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3].

The algorithm will iterate over this reference string and manage the page frames according to FIFO.

#### Step-by-step Output:

```
String | Frame →   0 1 2 
   ↓
   7        7         No
   0        7 0       Yes
   1        7 0 1     Yes
   2        0 1 2     Yes
   0        0 1 2     No
   3        1 2 3     Yes
   0        1 2 0     Yes
   4        2 0 4     Yes
   2        0 4 2     No
   3        4 2 3     Yes
   0        2 3 0     Yes
   3        3 0 2     No

Total requests: 12
Total Page Faults: 9
Fault Rate: 75.00%
```

### Explanation of Output:

1. **String**: Current page from the reference string being processed.
2. **Frame →**: The current contents of the memory frames after processing the page.
3. **Fault**: Indicates whether a page fault occurred ("Yes" or "No").
4. The table shows the state of the frames after each page request, and if a page is not in memory, it triggers a page fault and replaces the oldest page.

### Detailed Breakdown:
1. **Page 7** causes a page fault and is added to the frame.
2. **Page 0** causes a page fault, and the frame is updated to [7, 0].
3. **Page 1** causes a page fault, and the frame is updated to [7, 0, 1].
4. **Page 2** causes a page fault and replaces page 7, so the frame becomes [0, 1, 2].
5. **Page 0** is already in memory, so no page fault occurs.
6. **Page 3** causes a page fault and replaces page 1, so the frame becomes [0, 2, 3].
7. **Page 0** is already in memory, so no page fault occurs.
8. **Page 4** causes a page fault and replaces page 2, so the frame becomes [0, 3, 4].
9. **Page 2** causes a page fault and replaces page 3, so the frame becomes [0, 4, 2].
10. **Page 3** causes a page fault and replaces page 0, so the frame becomes [4, 2, 3].
11. **Page 0** causes a page fault and replaces page 4, so the frame becomes [2, 3, 0].
12. **Page 3** is already in memory, so no page fault occurs.

### Code Explanation:

- **`cin.peek()`** is used to check if the user has finished entering the reference string. This stops input when the user presses "Enter" (newline character).
- **`find(f.begin(), f.end(), s[i])`** checks if the current page (s[i]) is already in the frame (f). If not found, it's a page fault.
- If the frame is not full, the page is added to the frame. If the frame is full, the page at the `top` (oldest page) is replaced.
- **Page fault counter (`fault`)** is incremented each time a page is replaced or added.
- **`top`** is used to track the oldest page in the frame and is updated in a circular manner with `top = (top + 1) % capacity`.
- After processing the reference string, the statistics (total requests, page faults, and fault rate) are displayed.

### Conclusion:
The FIFO algorithm is simple but not optimal, as it can cause excessive page faults in certain scenarios, especially when the pages have long intervals between references. 
The output above shows how the page faults and the fault rate can be calculated and displayed for each page access in the reference string.*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    int capacity, fault = 0;
    string pf = "No";
    vector<int> f, st;

    // Input number of frames (capacity)
    cout << "Enter the number of frames: ";
    cin >> capacity;

    // Input reference string
    cout << "Enter the reference string: ";
    vector<int> s;
    int num;
    while (cin >> num) {
        s.push_back(num);
        if (cin.peek() == '\n') break;  // Stop when enter is pressed
    }

    // Print header
    cout << "\nString | Frame →\t";
    for (int i = 0; i < capacity; i++) {
        cout << i << " ";
    }
    cout << "Fault\n   ↓\n";

    for (int i : s) {
        auto it = find(f.begin(), f.end(), i);

        if (it == f.end()) {
            // Page fault, not found in frame
            if (f.size() < capacity) {
                f.push_back(i);
                st.push_back(f.size() - 1);  // Track index of added page
            } else {
                int ind = st.front();  // Least recently used page
                st.erase(st.begin());  // Remove the LRU page
                f[ind] = i;            // Replace the LRU page with new page
                st.push_back(ind);      // Track the new page index
            }
            pf = "Yes";
            fault++;
        } else {
            // Page hit, update LRU tracking
            int index = distance(f.begin(), it);
            st.erase(find(st.begin(), st.end(), index));  // Remove old position
            st.push_back(index);                          // Add to the end (most recent)
            pf = "No";
        }

        // Output the current status of frames and page fault status
        cout << "   " << i << "\t\t";
        for (int x : f) {
            cout << x << " ";
        }
        for (int x = 0; x < capacity - f.size(); x++) {
            cout << "  ";
        }
        cout << " " << pf << endl;
    }

    // Output total page faults and fault rate
    cout << "\nTotal Requests: " << s.size() << "\nTotal Page Faults: " << fault 
         << "\nFault Rate: " << (fault / (double)s.size()) * 100 << "%" << endl;

    return 0;
}




/*This code implements the **Least Recently Used (LRU)** page replacement algorithm, which keeps track of the pages that were accessed least recently and replaces them when new pages need to be loaded into memory.

### LRU Page Replacement Algorithm Overview:

In **LRU**, when a page needs to be replaced, the page that hasn't been used for the longest time is replaced. The algorithm uses a list or a stack-like structure to maintain the order in which pages were accessed. The least recently used page is the one that is removed when memory is full.

### Key Components of the Code:

1. **Frames (`f`)**: A vector that simulates the frames in memory where pages are loaded.
2. **Page Requests (`s`)**: A vector that holds the reference string (the sequence of page accesses).
3. **Tracking (`st`)**: A vector used to track the order of accessed pages, which helps in identifying the least recently used page.

### Step-by-Step Explanation:

1. **Input**:
   - The user is asked to enter the number of frames (capacity).
   - The reference string (sequence of page accesses) is taken as input.
   
2. **Page Faults**:
   - A page fault occurs when a page is accessed that is not currently in memory (i.e., it's not in the frame).
   - When a page fault happens and there is space in memory, the page is added to the frames.
   - If the memory is full, the least recently used page (the one that was last accessed the longest time ago) is replaced with the new page.

3. **Page Hit**:
   - A page hit occurs when the page being accessed is already in memory.
   - If there is a page hit, the order of the pages in memory is updated to reflect that this page was accessed most recently.

4. **Output**:
   - After each page access, the current status of the frames is displayed.
   - The output includes the reference string, the status of the frames (the pages in memory), and whether the access was a page fault or a page hit.

5. **Statistics**:
   - After processing all page accesses, the program prints the total number of requests, the total number of page faults, and the fault rate (as a percentage of total requests).

### Sample Input:
```
Enter the number of frames: 3
Enter the reference string: 7 0 1 2 0 3 0 4 2 3
```

### Explanation of the Input:
- Number of frames = 3
- Reference string = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3]

### Output:
```
String | Frame →        0 1 2 
   ↓
   7         7           Fault
   0         7 0         Fault
   1         7 0 1       Fault
   2         0 1 2       Fault
   0         0 1 2       No
   3         1 2 3       Fault
   0         2 3 0       No
   4         3 0 4       Fault
   2         0 4 2       Fault
   3         4 2 3       No

Total Requests: 10
Total Page Faults: 7
Fault Rate: 70.00%
```

### Explanation of the Output:

1. **Page Faults**:
   - Initially, all frames are empty, so the first 3 page accesses (7, 0, 1) result in faults as they are loaded into the frames.
   - When page 2 is accessed, it causes a fault, and the least recently used page (7) is replaced.
   - Page 0 causes no fault since it is already in the frame.
   - Page 3 causes a fault, and the least recently used page (1) is replaced.
   - Page 4 causes a fault, replacing the least recently used page (2).
   - Finally, after all accesses, the program outputs the total faults (7) and the fault rate (70%).

### Code Walkthrough:

- **`vector<int> f`**: Stores the pages currently in memory (the frames).
- **`vector<int> st`**: Tracks the order of access. This helps in identifying which page is the least recently used.
- **`find(f.begin(), f.end(), i)`**: Checks if the current page is already in memory.
- **`st.front()`**: Retrieves the index of the least recently used page (the first element in the tracking vector).
- **`st.push_back(index)`**: Updates the tracking vector by adding the most recently accessed page to the end.

### Key Steps:
1. **Page Fault**: If the page is not in memory, add it to the frame and update the `st` vector.
2. **Page Hit**: If the page is already in memory, update the `st` vector to mark it as most recently used.
3. **Output**: Display the status of the frames after each page access.

### Conclusion:

The **LRU Page Replacement** algorithm is an efficient method for managing memory when a system needs to replace pages. It aims to keep the most recently used pages in memory and replace the ones that haven't been used for the longest time. The provided code tracks page accesses and ensures that the least
 recently used page is replaced when necessary, providing a detailed view of how pages are handled in memory.*/
#include <iostream>
#include <vector>
using namespace std;

class MemoryManagement {
protected:
    vector<int> memoryBlocks;
    int numProcesses;
    vector<int> processSizes;
    vector<int> allocatedBlock;
    vector<int> blockSizeRem;

public:
    // Constructor to initialize memory block sizes and process sizes
    MemoryManagement() {
        // Input memory block sizes
        cout << "Enter sizes of the memory blocks (space-separated): ";
        int blockSize;
        while (cin >> blockSize) {
            memoryBlocks.push_back(blockSize);
            if (cin.peek() == '\n') break;  // Stop when enter is pressed
        }

        // Input number of processes
        cout << "Enter number of processes: ";
        cin >> numProcesses;

        // Input process sizes
        cout << "Enter sizes of the processes (space-separated): ";
        int processSize;
        for (int i = 0; i < numProcesses; i++) {
            cin >> processSize;
            processSizes.push_back(processSize);
        }

        // Initialize allocatedBlock to track which block is allocated to each process
        allocatedBlock.resize(numProcesses, -1);
        // Copy the memory block sizes to keep track of remaining memory
        blockSizeRem = memoryBlocks;
    }

    // Method to print the memory allocation table
    void printTable() {
        // Print table header
        cout << "Process   " << "Process Size   " << "Block Number   " << "Block Size   " << "Unused Memory" << endl;

        // Iterate through each process
        for (int i = 0; i < numProcesses; i++) {
            if (allocatedBlock[i] != -1) {
                // Print details of the allocated block
                cout << i + 1 << "          "
                     << processSizes[i] << "             "
                     << allocatedBlock[i] + 1 << "             "
                     << memoryBlocks[allocatedBlock[i]] << "             "
                     << blockSizeRem[allocatedBlock[i]] << endl;
            } else {
                // If no block was allocated, print N/A
                cout << i + 1 << "          "
                     << processSizes[i] << "             "
                     << "N/A           -             -" << endl;
            }
        }
        cout << endl;
    }
};

class NextFit : public MemoryManagement {
public:
    NextFit() : MemoryManagement() {}

    // Method to execute Next Fit memory allocation
    void execute() {
        int j = 0;  // Start searching from the beginning of the block list

        // Iterate over all processes
        for (int i = 0; i < numProcesses; i++) {
            bool allocated = false;

            // Search for the next fit block, starting from where the last allocation was made
            for (int k = 0; k < memoryBlocks.size(); k++) {
                // If the block can accommodate the process
                if (blockSizeRem[j] >= processSizes[i]) {
                    // Allocate the block to the process
                    allocatedBlock[i] = j;
                    // Reduce the available size of the block
                    blockSizeRem[j] -= processSizes[i];
                    allocated = true;
                    break;
                }

                // Move to the next block, wrapping around if necessary
                j = (j + 1) % memoryBlocks.size();
            }

            // Move to the next block after the current allocation, if allocated
            if (allocated) {
                j = (j + 1) % memoryBlocks.size();
            }
        }

        cout << "\nNEXT FIT - Memory Allocation:\n";
        printTable();
    }
};

int main() {
    // Create an object of NextFit class and execute the allocation
    NextFit nf;
    nf.execute();

    return 0;
}


/*This code implements the **Next Fit** memory allocation algorithm, which is a variation of the **First Fit** algorithm. It allocates memory to processes by searching for a suitable memory block starting from the position where the last allocation was made, rather than searching from the beginning of the memory block list every time.

### Next Fit Memory Allocation Algorithm Overview:

In the **Next Fit** algorithm:
- Memory blocks are allocated to processes in the order they arrive.
- The algorithm keeps track of the last position where a block was allocated, and the next allocation search starts from that position.
- If a process fits into a memory block, it is allocated. If not, the search continues through the list, wrapping around when necessary.

### Key Components of the Code:

1. **Memory Blocks (`memoryBlocks`)**: Stores the sizes of the available memory blocks.
2. **Process Sizes (`processSizes`)**: Stores the sizes of the processes that need to be allocated memory.
3. **Allocated Blocks (`allocatedBlock`)**: Keeps track of which block is allocated to each process (initialized to -1 for unallocated processes).
4. **Remaining Block Sizes (`blockSizeRem`)**: Stores the remaining sizes of memory blocks after allocation.

### Step-by-Step Explanation:

1. **Input**:
   - The user is prompted to enter the sizes of memory blocks.
   - The user is then asked for the number of processes.
   - The user is also asked to input the sizes of the processes.

2. **Next Fit Allocation**:
   - The algorithm starts searching for the next available block from the position where the last allocation was made.
   - If a block is large enough to accommodate the process, the process is allocated to that block, and the block's size is updated.
   - The search continues in a circular fashion, wrapping around to the beginning of the memory blocks if necessary.

3. **Output**:
   - The program displays a table with the allocation details, showing each process, its size, the allocated memory block, the block's size, and the remaining unused memory in that block.
   - If a process cannot be allocated to any memory block, the allocation for that process is marked as "N/A."

4. **Print Table**:
   - The `printTable()` method prints a table with the allocation details, showing for each process whether it was allocated a block or not.

### Sample Input:
```
Enter sizes of the memory blocks (space-separated): 100 500 200 300
Enter number of processes: 4
Enter sizes of the processes (space-separated): 212 417 112 426
```

### Explanation of the Input:
- Memory block sizes: [100, 500, 200, 300]
- Number of processes: 4
- Process sizes: [212, 417, 112, 426]

### Output:
```
NEXT FIT - Memory Allocation:
Process   Process Size   Block Number   Block Size   Unused Memory
1          212             2             200             88
2          417             3             300             0
3          112             4             300             188
4          426             N/A           -             -
```

### Explanation of the Output:
1. **Process 1 (212 units)**: It is allocated to block 2 (200 units), leaving 88 units unused.
2. **Process 2 (417 units)**: It is allocated to block 3 (300 units), leaving no unused memory.
3. **Process 3 (112 units)**: It is allocated to block 4 (300 units), leaving 188 units unused.
4. **Process 4 (426 units)**: No memory block is large enough to accommodate this process, so it is marked as "N/A."

### Code Walkthrough:

1. **MemoryManagement Class**:
   - This class handles the initialization of memory blocks and processes, as well as the display of the allocation table.
   
2. **NextFit Class**:
   - Inherits from `MemoryManagement` and implements the `execute()` method for the Next Fit allocation.
   - The allocation starts at the last position where a block was allocated (`j`), and the search continues from there.
   - If a process cannot be allocated to any block, the allocation remains marked as "N/A."

3. **Looping Through Processes**:
   - For each process, the algorithm searches for a suitable block starting from the current position (`j`), and continues the search until either a block is found or all blocks are checked.
   - The `j` pointer is updated to ensure that the search starts from the next block in the subsequent iterations.

4. **PrintTable Method**:
   - The table header and rows are printed, showing each process, its size, the allocated block number, the block size, and the remaining unused memory.

### Conclusion:

The **Next Fit** algorithm is an efficient memory allocation strategy that avoids starting the search for a fitting block from the beginning every time, making it slightly more efficient than the **First Fit** algorithm in some cases. The provided code takes user input for memory block sizes and process sizes, allocates memory 
using the Next Fit strategy, and outputs the allocation results in a formatted table.*/
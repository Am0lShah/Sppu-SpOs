#include <iostream>
#include <vector>
#include <iomanip>
#include <algorithm>
using namespace std;

// Function to find the waiting time for all processes
void findWaitingTime(const vector<int>& processes, int n, const vector<int>& burst_time, vector<int>& waiting_time) {
    // Waiting time for the first process is always 0
    waiting_time[0] = 0;

    // Calculating waiting time for each process
    for (int i = 1; i < n; i++) {
        waiting_time[i] = burst_time[i - 1] + waiting_time[i - 1];
    }
}

// Function to calculate turn-around time
void findTurnAroundTime(const vector<int>& processes, int n, const vector<int>& burst_time, const vector<int>& waiting_time, vector<int>& turn_around_time) {
    // Calculating turnaround time by adding burst_time and waiting_time
    for (int i = 0; i < n; i++) {
        turn_around_time[i] = burst_time[i] + waiting_time[i];
    }
}

// Function to sort processes by burst time using SJF logic
void sjfScheduling(vector<int>& processes, int n, vector<int>& burst_time) {
    vector<int> waiting_time(n, 0);
    vector<int> turn_around_time(n, 0);
    
    // Pair processes with their burst times
    vector<pair<int, int>> processes_burst(n);
    for (int i = 0; i < n; i++) {
        processes_burst[i] = make_pair(processes[i], burst_time[i]);
    }

    // Sorting the processes by their burst time
    sort(processes_burst.begin(), processes_burst.end(), [](const pair<int, int>& a, const pair<int, int>& b) {
        return a.second < b.second; // Compare by burst time
    });

    // Unzipping sorted processes and burst times
    for (int i = 0; i < n; i++) {
        processes[i] = processes_burst[i].first;
        burst_time[i] = processes_burst[i].second;
    }
    
    // Function to find waiting time of all processes
    findWaitingTime(processes, n, burst_time, waiting_time);
    
    // Function to find turn around time for all processes
    findTurnAroundTime(processes, n, burst_time, waiting_time, turn_around_time);
    
    // Display processes with their burst time, waiting time, and turn-around time
    cout << "\nProcess  Burst Time  Waiting Time  Turn Around Time" << endl;
    double total_waiting_time = 0;
    double total_turn_around_time = 0;
    for (int i = 0; i < n; i++) {
        total_waiting_time += waiting_time[i];
        total_turn_around_time += turn_around_time[i];
        cout << setw(7) << processes[i] << setw(11) << burst_time[i] 
             << setw(14) << waiting_time[i] << setw(17) << turn_around_time[i] << endl;
    }

    // Display average waiting time and turn-around time
    cout << fixed << setprecision(2);
    cout << "\nAverage Waiting Time: " << (total_waiting_time / n) << endl;
    cout << "Average Turn Around Time: " << (total_turn_around_time / n) << endl;
}

int main() {
    cout << "Shortest Job First (SJF) Scheduling:" << endl;

    // Input number of processes
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<int> processes(n);
    
    // Input process IDs
    cout << "Enter process IDs: ";
    for (int i = 0; i < n; i++) {
        cin >> processes[i];
    }

    // Input burst times
    vector<int> burst_time(n);
    cout << "Enter burst times: ";
    for (int i = 0; i < n; i++) {
        cin >> burst_time[i];
    }

    // Call the SJF scheduling function
    sjfScheduling(processes, n, burst_time);

    return 0;
}





/*The code you've provided implements the **Shortest Job First (SJF)** scheduling algorithm, which is a non-preemptive scheduling algorithm where processes are scheduled based on the shortest burst time first. It optimizes the average waiting time by executing the processes with the shortest burst times before the longer ones.

### Key Concepts of SJF Scheduling:

1. **Shortest Job First (SJF)**: This scheduling algorithm selects the process with the smallest burst time (i.e., the shortest time to complete its task) for execution first. It assumes that the burst times of processes are known in advance.
   
2. **Non-preemptive Scheduling**: Once a process starts its execution, it is not interrupted. The next process is selected based on the shortest burst time available in the ready queue.
   
3. **Waiting Time**: The time a process spends waiting in the ready queue before its execution starts.

4. **Turnaround Time**: The total time from when a process arrives in the ready queue to when it completes its execution.

### Algorithm Breakdown:

1. **Sorting the Processes**: The processes are sorted in ascending order of burst time. This ensures that the process with the shortest burst time is executed first.
   
2. **Waiting Time Calculation**: The waiting time for each process is calculated using the formula:
   \[
   \text{Waiting Time}_i = \text{Burst Time}_{i-1} + \text{Waiting Time}_{i-1}
   \]
   where \(i\) is the index of the process.

3. **Turnaround Time Calculation**: The turnaround time is calculated using the formula:
   \[
   \text{Turnaround Time}_i = \text{Burst Time}_i + \text{Waiting Time}_i
   \]
   
4. **Output**: The program displays the process details such as burst time, waiting time, and turnaround time. It also calculates and prints the average waiting time and average turnaround time.

### Code Walkthrough:

1. **Input**:
   - The user is prompted to enter the number of processes, their IDs, and their burst times.
   
2. **Sorting Processes by Burst Time**:
   - The processes are paired with their burst times into a vector of pairs. The processes are then sorted based on the burst time (ascending order) using `sort()`.

3. **Waiting Time Calculation**:
   - The waiting time for each process is calculated by accumulating the burst times of previous processes.
   
4. **Turnaround Time Calculation**:
   - The turnaround time is calculated by adding the burst time of a process to its waiting time.
   
5. **Output**:
   - The program displays the burst time, waiting time, and turnaround time for each process. It also calculates and prints the average waiting time and average turnaround time.

### Sample Input and Output:

**Input**:
```
Shortest Job First (SJF) Scheduling:
Enter number of processes: 3
Enter process IDs: 1 2 3
Enter burst times: 6 2 8
```

**Output**:
```
Process  Burst Time  Waiting Time  Turn Around Time
      2          2            0               2
      1          6            2               8
      3          8            8              16

Average Waiting Time: 3.33
Average Turn Around Time: 8.67
```

### Explanation of Output:

1. **Process 2** (with burst time 2) is the shortest, so it starts first with a waiting time of 0 and a turnaround time of 2.
2. **Process 1** (with burst time 6) is the next shortest, so it starts after Process 2 with a waiting time of 2 (waiting time of Process 2), and a turnaround time of 8.
3. **Process 3** (with burst time 8) is the longest and starts last. Its waiting time is the total burst time of Process 1 and Process 2, which is 8, and its turnaround time is 16.

The average waiting time and average turnaround time are calculated as:
- Average Waiting Time: \((0 + 2 + 8) / 3 = 3.33\)
- Average Turnaround Time: \((2 + 8 + 16) / 3 = 8.67\)

### Key Features:

1. **Sorting by Burst Time**:
   - The `sort()` function with a lambda comparator is used to arrange the processes by their burst times, ensuring the shortest burst time is executed first.
   
2. **Neat Output Formatting**:
   - The `setw()` function from the `<iomanip>` library ensures that the output is neatly aligned in columns for better readability.
   
3. **Floating-Point Precision**:
   - The average waiting time and average turnaround time are printed with two decimal places for more precise output.

### Conclusion:

This implementation of **Shortest Job First (SJF) Scheduling** efficiently handles scheduling by sorting processes based on their burst times. It calculates the waiting and turnaround times for each process and prints the results, making it useful for understanding how this scheduling algorithm works in practice. The code is simple, easy to understand,
 and outputs the necessary details for performance analysis of the scheduling algorithm.*/
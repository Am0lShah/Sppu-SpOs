#include<iostream>
#include<vector>

using namespace std;

struct process{
	int id;
	int arrivalTime;
	int bustTime;
	int waitingTime;
	int turnAroundTime;
	int completionTime;
	
	process(int id, int arrival, int bust): id(id),arrivalTime(arrival), bustTime(bust){}
};


void fcfs(vector<process>& processes){

	int n = processes.size();
	int totalWaitingTime=0;
	int totalTurnAroundTime=0;
	
	
	processes[0].completionTime=processes[0].arrivalTime+processes[0].bustTime;
	
	for(int i=1;i<n;++i){
		processes[i].completionTime=max(processes[i-1].completionTime,processes[i].arrivalTime)+processes[i].bustTime;
	} 
	
	
	for(int i=0; i<n;++i){
	
		processes[i].turnAroundTime = processes[i].completionTime - processes[i].arrivalTime;
		processes[i].waitingTime = processes[i].turnAroundTime - processes[i].bustTime;
		totalWaitingTime +=processes[i].waitingTime;
		totalTurnAroundTime+=processes[i].turnAroundTime;
	}
	
	
	cout<<"FCFS Sheduling algorithm"<<endl;
	cout<<"  id  "<<"    arrivalTime    "<<"    Bust Time    "<<"  Waiting Time  "<<"  Turn Around Time "<<"  Completion Time  "<<endl;
	
	for(const auto& p: processes){
	
	cout<<p.id<<" "<<p.arrivalTime<<" "<<p.bustTime<<" "<<p.waitingTime<<" "<<p.turnAroundTime<<" "<<p.completionTime<<endl;
	
	}

}

int main(){
	
	vector<process> processes;
	
	int n;
	cout<<"Enter the number of process  ";
	cin>>n;
	
	for(int i=0; i<n;i++){
		int arrival;
		int bust;
		cout<<"Enter "<<i<<" process arrival time "<<endl;
		cin>>arrival;
		cout<<"Enter "<<i<<" process bust time "<<endl;
		cin>>bust;
		processes.push_back(process(i+1,arrival, bust));
	}
	fcfs(processes);
	return 0;
}






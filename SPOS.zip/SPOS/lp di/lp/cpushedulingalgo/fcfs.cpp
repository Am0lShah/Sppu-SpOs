#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

// Define a structure to represent each process
struct Process {
    int id;             // Process ID
    int arrivalTime;    // Arrival time of the process
    int burstTime;      // Burst time (execution time) of the process
    int completionTime; // Time when process finishes
    int turnAroundTime; // Turnaround time = Completion time - Arrival time
    int waitingTime;    // Waiting time = Turnaround time - Burst time
    int priority;       // Priority (for Priority Scheduling)

    // Constructor to initialize process details
    Process(int id, int arrivalTime, int burstTime, int priority = 0)
        : id(id), arrivalTime(arrivalTime), burstTime(burstTime), priority(priority) {}
};

// Comparison function for SJF (sort by burst time)
bool compareBurstTime(const Process& p1, const Process& p2) {
    return p1.burstTime < p2.burstTime;
}

// Comparison function for Priority Scheduling (lower priority number means higher priority)
bool comparePriority(const Process& p1, const Process& p2) {
    return p1.priority < p2.priority;
}

// FCFS Scheduling Algorithm
void FCFS(vector<Process>& processes) {
    int n = processes.size();
    int totalWaitingTime = 0, totalTurnAroundTime = 0;
    processes[0].completionTime = processes[0].arrivalTime + processes[0].burstTime;
    
    for (int i = 1; i < n; ++i) {
        processes[i].completionTime = max(processes[i - 1].completionTime, processes[i].arrivalTime) + processes[i].burstTime;
    }

    for (int i = 0; i < n; ++i) {
        processes[i].turnAroundTime = processes[i].completionTime - processes[i].arrivalTime;
        processes[i].waitingTime = processes[i].turnAroundTime - processes[i].burstTime;
        totalWaitingTime += processes[i].waitingTime;
        totalTurnAroundTime += processes[i].turnAroundTime;
    }

    cout << "\nFCFS Scheduling:\n";
    cout << "PID | Arrival | Burst | Completion | Turnaround | Waiting\n";
    for (const auto& p : processes) {
        cout << p.id << "   | " << p.arrivalTime << "       | " << p.burstTime << "     | "
             << p.completionTime << "         | " << p.turnAroundTime << "         | " << p.waitingTime << "\n";
    }
    cout << "Average Waiting Time: " << (float)totalWaitingTime / n << endl;
    cout << "Average Turnaround Time: " << (float)totalTurnAroundTime / n << endl;
}

// SJF (Non-Preemptive) Scheduling Algorithm
void SJF(vector<Process>& processes) {
    int n = processes.size();
    int totalWaitingTime = 0, totalTurnAroundTime = 0;

    // Sort processes by burst time for SJF
    sort(processes.begin(), processes.end(), compareBurstTime);
    
    processes[0].completionTime = processes[0].arrivalTime + processes[0].burstTime;
    
    for (int i = 1; i < n; ++i) {
        processes[i].completionTime = max(processes[i - 1].completionTime, processes[i].arrivalTime) + processes[i].burstTime;
    }

    for (int i = 0; i < n; ++i) {
        processes[i].turnAroundTime = processes[i].completionTime - processes[i].arrivalTime;
        processes[i].waitingTime = processes[i].turnAroundTime - processes[i].burstTime;
        totalWaitingTime += processes[i].waitingTime;
        totalTurnAroundTime += processes[i].turnAroundTime;
    }

    cout << "\nSJF Scheduling:\n";
    cout << "PID | Arrival | Burst | Completion | Turnaround | Waiting\n";
    for (const auto& p : processes) {
        cout << p.id << "   | " << p.arrivalTime << "       | " << p.burstTime << "     | "
             << p.completionTime << "         | " << p.turnAroundTime << "         | " << p.waitingTime << "\n";
    }
    cout << "Average Waiting Time: " << (float)totalWaitingTime / n << endl;
    cout << "Average Turnaround Time: " << (float)totalTurnAroundTime / n << endl;
}

// Round Robin (RR) Scheduling Algorithm
void RoundRobin(vector<Process>& processes, int timeQuantum) {
    int n = processes.size();
    queue<Process*> readyQueue;
    vector<Process> completedProcesses;
    int totalWaitingTime = 0, totalTurnAroundTime = 0;
    int time = 0;

    // Initializing the ready queue with all processes
    for (int i = 0; i < n; ++i) {
        readyQueue.push(&processes[i]);
    }

    while (!readyQueue.empty()) {
        Process* current = readyQueue.front();
        readyQueue.pop();

        if (current->burstTime > timeQuantum) {
            current->burstTime -= timeQuantum;
            time += timeQuantum;
            readyQueue.push(current);
        } else {
            time += current->burstTime;
            current->completionTime = time;
            current->turnAroundTime = current->completionTime - current->arrivalTime;
            current->waitingTime = current->turnAroundTime - current->burstTime;
            completedProcesses.push_back(*current);
            totalWaitingTime += current->waitingTime;
            totalTurnAroundTime += current->turnAroundTime;
            current->burstTime = 0;
        }
    }

    cout << "\nRound Robin Scheduling (Quantum = " << timeQuantum << "):\n";
    cout << "PID | Arrival | Burst | Completion | Turnaround | Waiting\n";
    for (const auto& p : completedProcesses) {
        cout << p.id << "   | " << p.arrivalTime << "       | " << p.burstTime << "     | "
             << p.completionTime << "         | " << p.turnAroundTime << "         | " << p.waitingTime << "\n";
    }
    cout << "Average Waiting Time: " << (float)totalWaitingTime / n << endl;
    cout << "Average Turnaround Time: " << (float)totalTurnAroundTime / n << endl;
}

// Priority Scheduling (Non-Preemptive) Algorithm
void PriorityScheduling(vector<Process>& processes) {
    int n = processes.size();
    int totalWaitingTime = 0, totalTurnAroundTime = 0;

    // Sort processes by priority (lower number is higher priority)
    sort(processes.begin(), processes.end(), comparePriority);
    
    processes[0].completionTime = processes[0].arrivalTime + processes[0].burstTime;
    
    for (int i = 1; i < n; ++i) {
        processes[i].completionTime = max(processes[i - 1].completionTime, processes[i].arrivalTime) + processes[i].burstTime;
    }

    for (int i = 0; i < n; ++i) {
        processes[i].turnAroundTime = processes[i].completionTime - processes[i].arrivalTime;
        processes[i].waitingTime = processes[i].turnAroundTime - processes[i].burstTime;
        totalWaitingTime += processes[i].waitingTime;
        totalTurnAroundTime += processes[i].turnAroundTime;
    }

    cout << "\nPriority Scheduling:\n";
    cout << "PID | Arrival | Burst | Priority | Completion | Turnaround | Waiting\n";
    for (const auto& p : processes) {
        cout << p.id << "   | " << p.arrivalTime << "       | " << p.burstTime << "     | "
             << p.priority << "         | " << p.completionTime << "         | " << p.turnAroundTime << "         | " << p.waitingTime << "\n";
    }
    cout << "Average Waiting Time: " << (float)totalWaitingTime / n << endl;
    cout << "Average Turnaround Time: " << (float)totalTurnAroundTime / n << endl;
}

int main() {
    int n, timeQuantum;
    int choice;

    cout << "Enter the number of processes: ";
    cin >> n;

    vector<Process> processes;
    for (int i = 0; i < n; ++i) {
        int arrivalTime, burstTime, priority;
        cout << "Enter arrival time for process " << i + 1 << ": ";
        cin >> arrivalTime;
        cout << "Enter burst time for process " << i + 1 << ": ";
        cin >> burstTime;
        cout << "Enter priority for process " << i + 1 << " (lower value = higher priority, for Priority Scheduling): ";
        cin >> priority;
        processes.push_back(Process(i + 1, arrivalTime, burstTime, priority));
    }

    cout << "Choose a CPU scheduling algorithm:\n";
    cout << "1. FCFS\n";
    cout <<


#include<iostream>
#include<vector>
#include<queue>
#include <algorithm>

using namespace std;

struct process{
	int id;
	int arrivalTime;
	int bustTime;
	int waitingTime;
	int completionTime;
	int turnAroundTime;
	
	process(int id,int arrival,int bust):id(id),arrivalTime(arrival),bustTime(bust){};

};

void rr(vector<process>&processes,int quantumTime){
	int n = processes.size();
	cout<<n;
	queue<process*> readyQueue;
	vector<process> completedProcesses;
	int totalWaitingTime = 0, totalTurnAroundTime = 0;
    	int time = 0;
	
	for(int i=0;i<n;i++){
		readyQueue.push(&processes[i]);
	}
	
	while(!readyQueue.empty()){
	cout<<"hi";
		process* current=readyQueue.front();
		readyQueue.pop();
		if(current->bustTime>quantumTime){
			current->bustTime-=quantumTime;
			time+=quantumTime;
			readyQueue.push(current);
		}
		else{
			time+=quantumTime;
			current->completionTime=time;
			current->turnAroundTime=current->completionTime-current->arrivalTime;
			current->waitingTime=current->turnAroundTime-current->bustTime;
			completedProcesses.push_back(*current);
			totalWaitingTime+=current->waitingTime;
			totalTurnAroundTime+=current->turnAroundTime;
			current->bustTime=0;
		}
	
	}
	
	cout << "\nRound Robin Scheduling (Quantum = " << quantumTime << "):\n";
    cout << "PID | Arrival | Burst | Completion | Turnaround | Waiting\n";
    for (const auto& p : completedProcesses) {
        cout << p.id << "   | " << p.arrivalTime << "       | " << p.bustTime << "     | "
             << p.completionTime << "         | " << p.turnAroundTime << "         | " << p.waitingTime << "\n";
    }
    cout << "Average Waiting Time: " << (float)totalWaitingTime / n << endl;
    cout << "Average Turnaround Time: " << (float)totalTurnAroundTime / n << endl;

}

int main(){
	
	int n, timeQuantum;
    	

    cout << "Enter the number of processes: ";
    cin >> n;
	cout<<"Enter quntum time";
	cin>>timeQuantum;
    vector<process> processes;
    for (int i = 0; i < n; ++i) {
        int arrivalTime, burstTime, priority;
        cout << "Enter arrival time for process " << i + 1 << ": ";
        cin >> arrivalTime;
        cout << "Enter burst time for process " << i + 1 << ": ";
        cin >> burstTime;
        processes.push_back(process(i + 1, arrivalTime, burstTime));
    }
	rr(processes,timeQuantum);
	return 0;
}

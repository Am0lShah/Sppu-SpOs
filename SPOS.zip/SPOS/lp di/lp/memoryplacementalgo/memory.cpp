#include <iostream>
#include <vector>

using namespace std;

// Function to implement First Fit
void firstFit(vector<int>& blocks, vector<int>& processes) {
    cout << "First Fit Allocation:" << endl;
    for (int i = 0; i < processes.size(); i++) {
        bool allocated = false;
        for (int j = 0; j < blocks.size(); j++) {
            if (blocks[j] >= processes[i]) {
                cout << "Process " << i + 1 << " (size " << processes[i] << ") allocated to block " << j + 1 << " (size " << blocks[j] << ")." << endl;
                blocks[j] -= processes[i];  // Reduce the block size after allocation
                allocated = true;
                break;
            }
        }
        if (!allocated)
            cout << "Process " << i + 1 << " cannot be allocated." << endl;
    }
}

// Function to implement Next Fit
void nextFit(vector<int>& blocks, vector<int>& processes) {
    cout << "\nNext Fit Allocation:" << endl;
    int lastAllocated = 0;
    for (int i = 0; i < processes.size(); i++) {
        bool allocated = false;
        for (int j = lastAllocated; j < blocks.size(); j++) {
            if (blocks[j] >= processes[i]) {
                cout << "Process " << i + 1 << " (size " << processes[i] << ") allocated to block " << j + 1 << " (size " << blocks[j] << ")." << endl;
                blocks[j] -= processes[i];  // Reduce the block size after allocation
                lastAllocated = j;  // Update the last allocated block
                allocated = true;
                break;
            }
        }
        if (!allocated) {
            for (int j = 0; j < lastAllocated; j++) {
                if (blocks[j] >= processes[i]) {
                    cout << "Process " << i + 1 << " (size " << processes[i] << ") allocated to block " << j + 1 << " (size " << blocks[j] << ")." << endl;
                    blocks[j] -= processes[i];  // Reduce the block size after allocation
                    lastAllocated = j;  // Update the last allocated block
                    allocated = true;
                    break;
                }
            }
        }
        if (!allocated)
            cout << "Process " << i + 1 << " cannot be allocated." << endl;
    }
}

// Function to implement Worst Fit
void worstFit(vector<int>& blocks, vector<int>& processes) {
    cout << "\nWorst Fit Allocation:" << endl;
    for (int i = 0; i < processes.size(); i++) {
        int maxIndex = -1;
        for (int j = 0; j < blocks.size(); j++) {
            if (blocks[j] >= processes[i] && (maxIndex == -1 || blocks[j] > blocks[maxIndex])) {
                maxIndex = j;
            }
        }
        if (maxIndex != -1) {
            cout << "Process " << i + 1 << " (size " << processes[i] << ") allocated to block " << maxIndex + 1 << " (size " << blocks[maxIndex] << ")." << endl;
            blocks[maxIndex] -= processes[i];  // Reduce the block size after allocation
        } else {
            cout << "Process " << i + 1 << " cannot be allocated." << endl;
        }
    }
}

// Function to implement Best Fit
void bestFit(vector<int>& blocks, vector<int>& processes) {
    cout << "\nBest Fit Allocation:" << endl;
    for (int i = 0; i < processes.size(); i++) {
        int minIndex = -1;
        for (int j = 0; j < blocks.size(); j++) {
            if (blocks[j] >= processes[i] && (minIndex == -1 || blocks[j] < blocks[minIndex])) {
                minIndex = j;
            }
        }
        if (minIndex != -1) {
            cout << "Process " << i + 1 << " (size " << processes[i] << ") allocated to block " << minIndex + 1 << " (size " << blocks[minIndex] << ")." << endl;
            blocks[minIndex] -= processes[i];  // Reduce the block size after allocation
        } else {
            cout << "Process " << i + 1 << " cannot be allocated." << endl;
        }
    }
}

int main() {
    // Example blocks and processes
    vector<int> blocks = {100, 500, 200, 300, 600}; // Size of memory blocks
    vector<int> processes = {212, 417, 112, 426}; // Size of processes

    // Run all algorithms
    firstFit(blocks, processes);

    // Reinitialize blocks for next algorithm
    blocks = {100, 500, 200, 300, 600};
    nextFit(blocks, processes);

    // Reinitialize blocks for next algorithm
    blocks = {100, 500, 200, 300, 600};
    worstFit(blocks, processes);

    // Reinitialize blocks for next algorithm
    blocks = {100, 500, 200, 300, 600};
    bestFit(blocks, processes);

    return 0;
}


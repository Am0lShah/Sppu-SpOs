#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>

using namespace std;

class Semaphore {
private:
    mutex mtx;               // Mutex for synchronization
    condition_variable cv;   // Condition variable for blocking and waking threads
    int count;               // Number of available resources (initial count)

public:
    // Constructor to initialize the semaphore with a specific count
    Semaphore(int initial_count) : count(initial_count) {}

    // Wait (P operation) - Decrement the semaphore and block if count is 0
    void wait() {
        unique_lock<mutex> lock(mtx);  // Lock the mutex
        while (count == 0) {
            cv.wait(lock);  // Wait until the semaphore count is > 0
        }
        --count;  // Decrease the count (acquire the resource)
    }

    // Signal (V operation) - Increment the semaphore and notify one waiting thread
    void signal() {
        unique_lock<mutex> lock(mtx);  // Lock the mutex
        ++count;  // Increase the count (release the resource)
        cv.notify_one();  // Notify one waiting thread (if any)
    }

    // Get the current value of the semaphore
    int get_count() {
        unique_lock<mutex> lock(mtx);
        return count;
    }
};

mutex cout_mutex; // Mutex to synchronize console output

// Simulating a process that uses the semaphore
void process(Semaphore& sem, int id) {
    {
        lock_guard<mutex> lock(cout_mutex);
        cout << "Process " << id << " is waiting to enter...\n";
    }
    
    sem.wait();  // Wait for the semaphore to be available

    {
        lock_guard<mutex> lock(cout_mutex);
        cout << "Process " << id << " has entered the critical section.\n";
    }
    this_thread::sleep_for(chrono::seconds(1)); // Simulate some work

    {
        lock_guard<mutex> lock(cout_mutex);
        cout << "Process " << id << " is leaving the critical section.\n";
    }
    
    sem.signal();  // Signal that the process has finished and released the semaphore
}

int main() {
    Semaphore sem(3);  // Create a semaphore with 3 resources

    // Launch several threads (simulating multiple processes)
    vector<thread> threads;
    for (int i = 0; i < 5; ++i) {
        threads.push_back(thread(process, ref(sem), i + 1));
    }

    // Join all threads
    for (auto& t : threads) {
        t.join();
    }

    return 0;
}



/*The code you've provided demonstrates the usage of **semaphores** in a multithreaded environment using C++ standard libraries. A semaphore is a synchronization primitive used to control access to a shared resource by multiple threads in concurrent programming.

### Key Concepts:

1. **Semaphore**:
   - A **semaphore** is an integer value that is used to control access to shared resources.
   - It has two main operations:
     - **Wait (P operation)**: Decreases the semaphore value. If the value is zero, the calling thread is blocked until the value becomes greater than zero.
     - **Signal (V operation)**: Increases the semaphore value and may unblock a waiting thread.

2. **Critical Section**:
   - A **critical section** refers to a part of the program that accesses shared resources (e.g., variables, files, hardware) and needs to be protected from concurrent access by multiple threads to avoid data corruption.
   - In this example, each process/thread waits for the semaphore, enters the critical section, simulates some work by sleeping, and then signals that it has finished, allowing others to enter the critical section.

3. **Multithreading**:
   - This example uses the C++ `<thread>` library to create multiple threads.
   - A **mutex** (`mtx`) is used to synchronize access to the semaphore's internal state (`count`) and ensure that only one thread at a time can modify the `count` or perform any of the semaphore operations.
   - A **condition variable** (`cv`) is used for blocking and waking threads. When the semaphore count is zero, threads are blocked, and they are awakened when the count is incremented.

### Code Walkthrough:

1. **Semaphore Class**:
   - The class contains a `count` that tracks the available resources. 
   - The `wait()` method blocks the calling thread if the count is zero. It waits on the condition variable (`cv`) until the semaphore count is greater than zero.
   - The `signal()` method increments the count and notifies one waiting thread, allowing it to proceed.
   - The `get_count()` method returns the current count of the semaphore.

2. **Simulating a Process**:
   - The `process()` function simulates a process that attempts to access a shared resource. Each process calls `sem.wait()` to enter the critical section and `sem.signal()` to exit the critical section.
   - The `this_thread::sleep_for()` is used to simulate some work being done inside the critical section.

3. **Main Function**:
   - The semaphore is initialized with a count of `3`, meaning up to three processes can simultaneously enter the critical section.
   - Five threads are created to simulate processes. Each thread runs the `process()` function.
   - The `join()` method ensures that the main thread waits for all the child threads to finish.

### Example Execution:

With the semaphore initialized with a count of 3, the first 3 processes can enter the critical section simultaneously. Once one of them exits and signals the semaphore, another process can enter.

#### Expected Output:

```
Process 1 is waiting to enter...
Process 2 is waiting to enter...
Process 3 is waiting to enter...
Process 4 is waiting to enter...
Process 5 is waiting to enter...
Process 1 has entered the critical section.
Process 2 has entered the critical section.
Process 3 has entered the critical section.
Process 1 is leaving the critical section.
Process 4 is waiting to enter...
Process 2 is leaving the critical section.
Process 5 is waiting to enter...
Process 3 is leaving the critical section.
Process 4 has entered the critical section.
Process 4 is leaving the critical section.
Process 5 has entered the critical section.
Process 5 is leaving the critical section.
```

### Explanation:

1. The first three processes (`Process 1`, `Process 2`, and `Process 3`) are allowed to enter the critical section since the semaphore count is 3.
2. After `Process 1` finishes and signals the semaphore, `Process 4` is allowed to enter.
3. Similarly, `Process 5` enters after `Process 2` finishes.

### Thread Synchronization:

- **Mutex** (`mtx`) ensures that only one thread can modify the `count` at a time, preventing race conditions.
- **Condition Variable** (`cv`) is used to block threads when no resources are available and notify them when a resource becomes available.

### Potential Use Cases:

This program simulates a basic version of controlling access to a shared resource in multithreading scenarios, such as:
- Managing access to a fixed number of database connections.
- Controlling access to limited hardware resources.
- Implementing bounded buffers or producer-consumer problems.

### Improvements:

- **Error Handling**: There is no explicit error handling or checks for invalid operations, such as a thread calling `signal()` without having waited first. Adding checks or limits could improve robustness.
- **Dynamic Resource Management**: The current semaphore implementation is static (it doesn’t allow dynamic adjustments of resources). You could add functionality to increase or decrease the semaphore count at runtime based on resource availability.

This code provides a good foundation for understanding semaphores and their role in managing concurrent access to shared resources in a multithreaded environment.*/
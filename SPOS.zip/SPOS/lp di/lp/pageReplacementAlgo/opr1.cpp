#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int optimalPageReplacement(vector<int>& pages, int n, int capacity) {
    vector<int> frame;  // stores pages in memory
    int pageFaults = 0;

    for (int i = 0; i < n; i++) {
        int page = pages[i];
        
        // Check if the page is already in the frame (hit)
        if (find(frame.begin(), frame.end(), page) != frame.end()) {
            continue; // Page already in memory, no page fault
        }
        
        // If the frame has space, simply add the page
        if (frame.size() < capacity) {
            frame.push_back(page);
            pageFaults++;
        } else {
            // If the frame is full, we need to replace a page
            int farthest = -1, pageToReplace = -1;
            
            // Find the page to replace (the one that will be used farthest in the future)
            for (int j = 0; j < frame.size(); j++) {
                int index = -1;
                for (int k = i + 1; k < n; k++) {
                    if (frame[j] == pages[k]) {
                        index = k;
                        break;
                    }
                }
                // If page is not found in future, replace it immediately
                if (index == -1) {
                    pageToReplace = j;
                    break;
                }
                // Track the page that will be used farthest
                if (index > farthest) {
                    farthest = index;
                    pageToReplace = j;
                }
            }

            // Replace the page in the frame
            frame[pageToReplace] = page;
            pageFaults++;
        }
    }

    return pageFaults;
}

int main() {
    vector<int> pages = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 0};
    int n = pages.size();
    int capacity = 3;  // Number of page frames in memory
    
    int result = optimalPageReplacement(pages, n, capacity);
    
    cout << "Total Page Faults: " << result << endl;
    
    return 0;
}


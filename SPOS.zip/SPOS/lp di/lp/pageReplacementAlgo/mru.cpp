#include <iostream>
#include <deque>
#include <unordered_map>
#include <algorithm>  // Include this for std::remove

using namespace std;

void mru(int pages[], int n, int frameSize) {
    deque<int> frame;
    unordered_map<int, int> pagemap;
    int pagefault = 0;

    for (int i = 0; i < n; i++) {
        int page = pages[i];

        // If the page is not already in the cache (frame)
        if (pagemap.find(page) == pagemap.end()) {
            // If the frame is full, remove the most recently used page (at the front)
            if (frame.size() == frameSize) {
                int remov = frame.front();  // Most recently used is at the front
                frame.pop_front();  // Remove it from the frame
                pagemap.erase(remov);  // Remove it from the map
            }
            frame.push_front(page);  // Add the new page at the front (most recently used)
            pagemap[page] = 1;  // Mark page as recently used
            pagefault++;  // Increment page fault count
        } else {
            // If page is already in the frame, move it to the front (most recently used)
            frame.erase(remove(frame.begin(), frame.end(), page), frame.end());  // Remove the page
            frame.push_front(page);  // Add it to the front (most recently used)
        }
    }

    // Print total page faults
    cout << "Total Page Faults: " << pagefault << endl;
}

int main() {
    int pages[] = {2, 4, 5, 6, 4, 3, 6};  // Example page reference string
    int n = sizeof(pages) / sizeof(pages[0]);  // Number of pages
    int frameSize = 3;  // Size of the page frame (cache size)
    
    mru(pages, n, frameSize);  // Call MRU page replacement function
    return 0;
}

